<?php $__env->startSection('title',$s->data['seo_title'] ?? $s->title.' | Bikrify'); ?>
<?php $__env->startSection('desc',$s->data['meta_description'] ?? $s->intro); ?>
<?php $__env->startPush('structured-data'); ?>
<?php
 $serviceSchema=['@context'=>'https://schema.org','@type'=>'Service','name'=>$s->title,'description'=>$s->intro,'provider'=>['@type'=>'Organization','name'=>'Bikrify','url'=>route('home')],'areaServed'=>['@type'=>'Country','name'=>'Bangladesh'],'url'=>route('service',$s)];
 $faqSchema=['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>collect($s->data['faq'])->map(fn($faq)=>['@type'=>'Question','name'=>$faq[0],'acceptedAnswer'=>['@type'=>'Answer','text'=>$faq[1]]])->values()->all()];
?>
<script type="application/ld+json"><?php echo Illuminate\Support\Js::encode($serviceSchema); ?></script>
<script type="application/ld+json"><?php echo Illuminate\Support\Js::encode($faqSchema); ?></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-mist"><div class="mx-auto max-w-6xl px-5 py-14 md:py-20">
 <p class="text-sm"><a class="hover:text-brand" href="<?php echo e(route('home')); ?>">Home</a> / <a class="hover:text-brand" href="<?php echo e(route('home')); ?>#services">Services</a> / <?php echo e($s->title); ?></p>
 <h1 class="mt-5 max-w-3xl text-4xl font-semibold leading-tight text-brand md:text-5xl"><?php echo e($s->data['h1'] ?? $s->title); ?></h1>
 <p class="mt-4 max-w-2xl text-xl text-ink"><?php echo e($s->tagline); ?></p>
 <p class="mt-4 max-w-2xl"><?php echo e($s->intro); ?></p>
 <a href="#demo" class="mt-8 inline-block rounded-full bg-spark px-7 py-3.5 font-medium text-white hover:bg-orange-600">Book a free demo</a>
</div></section>
<section class="mx-auto grid max-w-6xl gap-6 px-5 py-16 md:grid-cols-2">
 <div class="rounded-3xl border border-slate-200 p-7"><h2 class="text-xl font-medium text-brand">Problems we remove</h2>
  <ul class="mt-4 space-y-3"><?php $__currentLoopData = $s->data['problems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="flex gap-3"><span class="mt-2 h-2 w-2 shrink-0 rounded-full bg-red-500"></span><?php echo e($p); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
 <div class="rounded-3xl bg-brand p-7 text-white"><h2 class="text-xl font-medium">What you get instead</h2>
  <ul class="mt-4 space-y-3"><?php $__currentLoopData = $s->data['solutions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="flex gap-3"><span class="mt-2 h-2 w-2 shrink-0 rounded-full bg-spark"></span><?php echo e($p); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
</section>
<?php if(!empty($s->data['sections'])): ?>
<section class="mx-auto max-w-4xl space-y-10 px-5 py-16">
 <?php $__currentLoopData = $s->data['sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$heading,$copy]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div><h2 class="text-2xl font-semibold text-brand"><?php echo e($heading); ?></h2><p class="mt-4 leading-8"><?php echo e($copy); ?></p></div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php endif; ?>
<section class="bg-mist py-12"><div class="mx-auto max-w-6xl px-5">
 <h2 class="text-2xl font-semibold text-brand">Explore related services</h2>
 <ul class="mt-4 flex flex-wrap gap-x-6 gap-y-3">
  <?php $__currentLoopData = $relatedServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li><a class="text-brand underline" href="<?php echo e(route('service',$related)); ?>"><?php echo e($related->title); ?></a></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
</div></section>
<section class="bg-mist py-16"><div class="mx-auto max-w-6xl px-5">
 <h2 class="text-3xl font-semibold text-brand">Capabilities</h2>
 <div class="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
  <?php $__currentLoopData = $s->data['caps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$t,$d]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="rounded-2xl bg-white p-6"><h3 class="font-medium text-brand"><?php echo e($t); ?></h3><p class="mt-2 text-sm"><?php echo e($d); ?></p></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</div></section>
<section class="mx-auto max-w-6xl px-5 py-16">
 <h2 class="text-3xl font-semibold text-brand">How we roll it out</h2>
 <ol class="mt-8 grid gap-5 md:grid-cols-4">
  <?php $__currentLoopData = $s->data['steps']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>[$t,$d]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li class="border-l-4 border-spark pl-4"><p class="font-medium text-brand"><?php echo e($i+1); ?>. <?php echo e($t); ?></p><p class="mt-1 text-sm"><?php echo e($d); ?></p></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ol>
</section>
<section class="mx-auto max-w-3xl px-5 pb-16">
 <h2 class="text-3xl font-semibold text-brand">Pricing</h2>
 <p class="mt-3">Pricing depends on modules, users, and branches. We give a fixed quote after a short discovery call.</p>
 <h2 class="mt-12 text-3xl font-semibold text-brand">Common questions</h2>
 <div class="mt-5 divide-y divide-slate-200 border-y border-slate-200">
  <?php $__currentLoopData = $s->data['faq']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$q,$a]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><details class="py-4"><summary class="cursor-pointer font-medium text-brand"><?php echo e($q); ?></summary><p class="mt-2"><?php echo e($a); ?></p></details><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</section>
<?php echo $__env->make('partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rahat\Bikrify.io\resources\views/service.blade.php ENDPATH**/ ?>