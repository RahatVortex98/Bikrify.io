<?php $__env->startSection('title','Bikrify Blog | Practical Business Software Guides'); ?>
<?php $__env->startSection('desc','Practical guides for Bangladeshi businesses on online orders, inventory, POS, and choosing business software.'); ?>
<?php $__env->startSection('content'); ?>
<section class="bg-mist"><div class="mx-auto max-w-6xl px-5 py-14 md:py-20">
 <h1 class="text-4xl font-semibold text-brand md:text-5xl">Bikrify blog</h1>
 <p class="mt-4 max-w-2xl text-lg">Practical notes on managing orders, stock, and everyday business work with software.</p>
</div></section>
<section class="mx-auto max-w-6xl px-5 py-14">
 <?php if($posts->isEmpty()): ?>
  <p class="rounded-2xl bg-mist p-6">No articles have been published yet. Please check back later.</p>
 <?php else: ?>
  <div class="grid gap-6 md:grid-cols-2">
   <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article class="rounded-3xl border border-slate-200 p-7">
     <p class="text-sm text-slate-500"><time datetime="<?php echo e($post->published_at->toAtomString()); ?>"><?php echo e($post->published_at->timezone('Asia/Dhaka')->format('j M Y')); ?></time></p>
     <h2 class="mt-3 text-2xl font-semibold text-brand"><a href="<?php echo e(route('blog.show',$post)); ?>" class="hover:underline"><?php echo e($post->title); ?></a></h2>
     <p class="mt-3"><?php echo e($post->excerpt); ?></p>
     <a class="mt-5 inline-block font-medium text-spark hover:underline" href="<?php echo e(route('blog.show',$post)); ?>">Read article</a>
    </article>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="mt-8"><?php echo e($posts->links()); ?></div>
 <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rahat\Bikrify.io\resources\views/blog/index.blade.php ENDPATH**/ ?>