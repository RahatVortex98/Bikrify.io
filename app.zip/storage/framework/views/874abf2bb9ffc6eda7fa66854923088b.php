<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['dark'=>false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['dark'=>false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<span class="inline-flex items-center gap-2.5">
 <svg width="38" height="38" viewBox="0 0 72 72" aria-hidden="true"><rect width="72" height="72" rx="16" fill="<?php echo e($dark ? '#fff' : '#1E3A8A'); ?>"/><path d="M22 16H42Q54 16 54 27Q54 34 48 36Q56 38 56 47Q56 58 44 58H22Z" fill="<?php echo e($dark ? '#1E3A8A' : '#fff'); ?>"/><path d="M31 24H40Q45 24 45 28Q45 32 40 32H31Z M31 40H42Q47 40 47 45Q47 50 42 50H31Z" fill="<?php echo e($dark ? '#fff' : '#1E3A8A'); ?>"/><circle cx="62" cy="10" r="6" fill="#F97316"/></svg>
 <span class="text-xl font-medium <?php echo e($dark ? 'text-white' : 'text-brand'); ?>">Bikrify</span>
</span>
<?php /**PATH F:\rahat\Bikrify.io\resources\views/components/logo.blade.php ENDPATH**/ ?>