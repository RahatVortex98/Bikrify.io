<section id="demo" class="bg-brand py-16">
 <div class="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-2">
  <div class="text-white">
   <h2 class="text-3xl font-semibold leading-tight md:text-4xl">See it with your own products.</h2>
   <p class="mt-4 max-w-md text-blue-100">Book a free 5-minute demo. We reply within one business day, no pressure and no confusing tech talk.</p>
  </div>
  <form method="post" action="<?php echo e(route('demo')); ?>" class="grid gap-4 rounded-3xl bg-white p-6">
   <?php echo csrf_field(); ?>
   <?php if(session('ok')): ?><p role="status" class="rounded-xl bg-green-50 p-3 text-sm text-green-800"><?php echo e(session('ok')); ?></p><?php endif; ?>
   <input type="text" name="website" class="hidden" tabindex="-1" autocomplete="off" aria-hidden="true">
   <?php $__currentLoopData = [['name','Your name','text',true],['phone','Phone or WhatsApp','tel',true],['email','Email (optional)','email',false],['business','Business name (optional)','text',false]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$f,$l,$t,$req]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <label class="grid gap-1 text-sm font-medium text-brand"><?php echo e($l); ?>

     <input type="<?php echo e($t); ?>" name="<?php echo e($f); ?>" value="<?php echo e(old($f)); ?>" <?php if($req): echo 'required'; endif; ?> class="rounded-xl border border-slate-300 px-4 py-3 font-normal text-slate-800 focus:border-brand focus:outline-2 focus:outline-brand">
     <?php $__errorArgs = [$f];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs font-normal text-red-600"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </label>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <label class="grid gap-1 text-sm font-medium text-brand">What do you need?
    <select name="service" class="rounded-xl border border-slate-300 px-4 py-3 font-normal text-slate-800">
     <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option <?php if(old('service',$s->title??'')==$n->title): echo 'selected'; endif; ?>><?php echo e($n->title); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <option>Not sure yet</option>
    </select>
   </label>
   <button class="rounded-full bg-spark px-6 py-3.5 font-medium text-white hover:bg-orange-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand">Book my free demo</button>
  </form>
 </div>
</section>
<?php /**PATH F:\rahat\Bikrify.io\resources\views/partials/form.blade.php ENDPATH**/ ?>