<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Sign in | Bikrify Admin</title>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head><body class="min-h-screen bg-mist font-sans text-slate-800">
<main class="mx-auto max-w-md px-5 py-16">
 <a href="<?php echo e(route('home')); ?>" aria-label="Bikrify home"><?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?></a>
 <div class="mt-8 rounded-3xl border border-slate-200 bg-white p-7 shadow-lg">
  <h1 class="text-2xl font-semibold text-brand">Admin sign in</h1>
  <?php if($errors->any()): ?><p role="alert" class="mt-4 text-sm text-red-700"><?php echo e($errors->first()); ?></p><?php endif; ?>
  <form method="post" action="<?php echo e(route('admin.login.store')); ?>" class="mt-6 grid gap-5">
   <?php echo csrf_field(); ?>
   <label class="grid gap-2">Email<input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="username" autofocus class="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"></label>
   <label class="grid gap-2">Password<input type="password" name="password" required autocomplete="current-password" class="rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900"></label>
   <button class="rounded-full bg-spark px-6 py-3 font-medium text-white">Sign in</button>
  </form>
 </div>
</main></body></html>
<?php /**PATH F:\rahat\Bikrify.io\resources\views/admin/login.blade.php ENDPATH**/ ?>